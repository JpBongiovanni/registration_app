from django.apps import AppConfig


class RegistrationAppConfig(AppConfig):
    name = 'registration_app'
